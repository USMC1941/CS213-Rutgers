package app;

import java.io.IOException;

import view.CalcController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Calculator extends Application {

	Stage mainStage;
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		mainStage = primaryStage;
		
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/view/calc.fxml"));
			GridPane root = loader.load();
			Scene scene = new Scene(root);
			
			// start up the calculator
			CalcController calcController = loader.getController();
			calcController.start();
			
			mainStage.setScene(scene);
			mainStage.setTitle("Calculator");
			mainStage.setResizable(false);
			mainStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
}
