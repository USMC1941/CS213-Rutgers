### Chess Project for Software Methadology (CS 213) at Rutgers University ###

* This is the Chess project for Software Methadology (CS 213).
* My name is William Chen and my partner is Chijun Sha.