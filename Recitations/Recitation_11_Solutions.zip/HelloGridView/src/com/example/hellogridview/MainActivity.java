package com.example.hellogridview;

import android.os.Bundle;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.Toast;

public class MainActivity extends Activity {

	public ImageAdapter myImgAdapter;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_main);
	    
	    myImgAdapter = new ImageAdapter(this);
	    GridView gridview = (GridView) findViewById(R.id.gridview);
	    gridview.setAdapter(myImgAdapter);

	    gridview.setOnItemClickListener(new OnItemClickListener() {
		public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
	        LayoutInflater inflater = getLayoutInflater();
	        View view = inflater.inflate(R.layout.toast_layout,
	                                       (ViewGroup) findViewById(R.id.relativeLayout1));
	        view.setBackgroundResource(myImgAdapter.getImgID(position));
	        
	        Toast toast = new Toast(parent.getContext());
	        toast.setView(view);
	        toast.show();
		}
	    });
	    /*gridview.setOnItemClickListener(new OnItemClickListener() {
	        public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
	            Toast.makeText(MainActivity.this, "" + position, Toast.LENGTH_SHORT).show();
	        }
	    });*/
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}


}
